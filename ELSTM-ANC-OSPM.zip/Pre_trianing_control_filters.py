import torch
from scipy import signal


from Noise_reduction_level_calculat import NR_level_compute
from Reading_path_tst import loading_paths_from_MAT
from FxMCC_algroithm import DistDisturbance_reference_generation_from_Fvector, FxLMS_algroithm, \
    Disturbance_reference_generation_gauss
import numpy as np
from FxMCC_algroithm import FxMCC_algroithm, train_fxlms_algorithm


from scipy.io import savemat
import scipy.io as sio

from SoundGenerator import rasd_noise, gaussian_mixture_noise, chaotic_noise, k_distribution, gauss_noise

noise_type = [1,2,3,4,5]

def save_mat__(FILE_NAME_PATH, Wc):
    mdict= {'Wc_v': Wc}
    savemat(FILE_NAME_PATH, mdict)


class Fxied_filters():

    def __init__(self, MATFILE_PATH, fs):
        mat_contents = sio.loadmat(MATFILE_PATH)
        self.Wc_vectors = mat_contents['Wc_v']
        self.len = len(self.Wc_vectors)
        self.filterlen = self.Wc_vectors.shape[1]
        self.Charactors = torch.zeros([self.len, 1, fs], dtype=torch.float)
        self.fs = fs

        for ii in range(self.len):
            self.Charactors[ii] = self.frequency_charactors_tensor(ii)

    def cancellator(self, classID, Fx, Dir):
        Yt = signal.lfilter(self.Wc_vectors[classID, :], 1, Fx)
        Er = Dir - Yt
        return Er

    def frequency_charactors_tensor(self, classID):
        fs = self.fs
        N = fs + self.filterlen
        if classID == 0:
            Re = gaussian_mixture_noise(N)
            Re = np.array(Re)
        elif classID == 1:
            Re = rasd_noise(N)
            Re = np.array(Re)
        elif classID == 2:
            Re = chaotic_noise(N)
            Re = np.array(Re)
        elif classID == 3:
            Re = k_distribution(N)
            Re = np.array(Re)
        elif classID == 4:
            Re = gauss_noise(N)
            Re = np.array(Re)
        else:
            raise ValueError("noise_type should in range 0-4!")
        b2 = signal.firwin(1024, [20, 1000], pass_zero='bandpass', window='hamming', fs=fs)
        yout = signal.lfilter(b2, 1, Re)
        yout = yout[self.filterlen:]
        # # print(self.Wc_vectors[classID,:])
        # yout = signal.lfilter(self.Wc_vectors[classID, :], 1, Re)
        # yout = yout[self.filterlen:]
        # # Standarlize
        # # yout = yout/np.sqrt(np.var(yout))
        # yout = minmaxscaler(yout)
        # # return a tensor of [1 x sample rate]

        return torch.from_numpy(yout).type(torch.float).unsqueeze(0)

def main():
    FILE_NAME_PATH = 'Control_Filter_MCC_2Sz.mat'
    # Configurating the system parameters
    fs = 16000 
    T  = 10
    Len_control = 1024
    noise_type = [0, 1, 2, 3, 4]
    sigma_total = [0.38, 0.47, 0.35, 0.39, 0.38]
    # sigma_total =[0.08, 0.19, 0.25, 0.39, 0.47]
    F_vector = [[1, 230], [200, 420], [400, 630], [600, 820], [800, 1000]]
    # F_vector = [[20, 550], [450, 1200], [1000, 2700], [2500, 4500], [4400, 7979]]
    # Loading the primary and secondary path
    Pri_path, Secon_path = loading_paths_from_MAT()
    # Pri_path, Secon_path = loading_paths_from_MAT(Sec_path_file_name='Sz_unknown.mat')
    # Training the control filters from the defined frequency band 
    num_noise = len(noise_type)
    Wc_matrix   = np.zeros((num_noise, Len_control), dtype=float)
    
    for ii, f_vector in zip(noise_type, F_vector):
        Dis, Fx = DistDisturbance_reference_generation_from_Fvector(fs=fs, T= T, noise_type=ii,
                                                                    Pri_path=Pri_path, Sec_path=Secon_path, f_vector=f_vector)
        # Dis, Fx = Disturbance_reference_generation_gauss(noise_type=ii)
        controller = FxMCC_algroithm(Len=Len_control, sigma=sigma_total[ii])
        # controller = FxLMS_algroithm(Len=Len_control)
        Erro = train_fxlms_algorithm(Model=controller,Ref=Fx, Disturbance=Dis)
        Wc_matrix[ii] = controller._get_coeff_()
        
        # Drawing the impulse response of the primary path
        # plt.title('The error signal of the FxLMS algorithm')
        # plt.plot(Erro)
        # plt.ylabel('Amplitude')
        # plt.xlabel('Time')
        # plt.grid()
        # plt.show()
        Nr = NR_level_compute(Dis, Erro)
        print(f'the noise reduction level is {Nr} dB !!')
    save_mat__(FILE_NAME_PATH, Wc_matrix)




if __name__ == "__main__":
    main()