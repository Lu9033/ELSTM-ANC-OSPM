import numpy as np
from torch import nn

from Pre_trianing_control_filters import Fxied_filters
from dataloader import minmaxscaler
from lstm_pre import load_weigth_for_model
from noise_cancellation import Casting_single_time_length_of_training_noise, \
    Casting_multiple_time_length_of_primary_noise


class OneD_CNN_Pre(nn.Module):

    def __init__(self):
        super().__init__()
        # First layer
        self.conv1 = nn.Conv1d(
            in_channels=1,
            out_channels=10,
            kernel_size=3,
            stride=1
        )
        # Secondary layer
        self.conv2 = nn.Sequential(
            nn.Conv1d(
                in_channels=10,
                out_channels=20,
                kernel_size=32,
                stride=1
            ),
            # Max-pool
            nn.MaxPool1d(
                kernel_size=512,
                stride=512
            )
        )

    def forward(self, input_data):
        x = self.conv1(input_data)
        x = self.conv2(x)
        logit = x.view(x.shape[0], -1)

        return logit


class OneD_CNN_Predictor():

    def __init__(self, MODEL_PATH, device):
        self.cnn = OneD_CNN_Pre().to(device)
        load_weigth_for_model(self.cnn, MODEL_PATH, device)
        self.cnn.eval()
        self.cos = nn.CosineSimilarity(dim=1).to(device)
        # self.cos.eval()
        self.device = device

    def cosSimilarity(self, signal_1, signal_2):
        signal1, signal2 = signal_1.unsqueeze(0), signal_2.unsqueeze(0)
        similarity = self.cos(self.cnn(signal1.to(self.device)), self.cnn(signal2.to(self.device)))
        return similarity.cpu().item()

    def cosSimilarity_minmax(self, signal_1, signal_2):
        signal1, signal2 = minmaxscaler(signal_1).unsqueeze(0), minmaxscaler(signal_2).unsqueeze(0)
        similarity = self.cos(self.cnn(signal1.to(self.device)), self.cnn(signal2.to(self.device)))
        return similarity.cpu().item()

class Control_filter_Index_predictor_CNN(OneD_CNN_Predictor):

    def __init__(self, MODEL_PATH, device, filter_training_noise, fs):

        OneD_CNN_Predictor.__init__(self, MODEL_PATH, device)
        # Checking the length of the training noise
        assert filter_training_noise.dim() == 3, 'The dimension of the training noise should be 3 !!!'
        assert filter_training_noise.shape[2] % fs == 0, 'The length of the training noise sample should be 1 second!'
        # Detach the information of the training noise
        self.frequency_charactors_tensor = filter_training_noise
        self.len_of_class = filter_training_noise.shape[0]
        self.fs = fs

    def predic_ID(self, noise):
        similarity_rato = []
        for ii in range(self.len_of_class):
            similarity_rato.append(self.cosSimilarity_minmax(noise, self.frequency_charactors_tensor[ii]))
        index = np.argmax(similarity_rato)
        return index

    def predic_ID_vector(self, primary_noise):
        # Checking the length of the primary noise.
        assert primary_noise.shape[0] == 1, 'The dimension of the primary noise should be [1 x samples] !!!'
        assert primary_noise.shape[
                   1] % self.fs == 0, 'The length of the primary noise is not an integral multiple of fs.'
        # Computing how many seconds the primary noise containt.
        Time_len = int(primary_noise.shape[1] / self.fs)
        print(Time_len)
        print(f'The primary nosie has {Time_len} seconds !!!')
        # Bulding the matric of the primary noise [times x 1 x fs ]
        primary_noise_vectors = primary_noise.reshape(Time_len, self.fs).unsqueeze(1)

        # Implementing the noise classification for each frame whose length is 1 second.
        ID_vector = []
        for ii in range(Time_len):
            ID_vector.append(self.predic_ID(primary_noise_vectors[ii]))

        return ID_vector

def Control_filter_selection_CNN(MODEL_PTH, Primary_noise, Filter_mat_name, fs=16000):
    # Frequecy_band = [[1, 230], [200, 420], [400, 630], [600, 820], [800, 1000]]
    # Creating the pre-trained band filter for 5 different frequency band


    Fxied_control_filter = Fxied_filters(MATFILE_PATH=Filter_mat_name, fs=fs)

    Charactors = Casting_single_time_length_of_training_noise(Fxied_control_filter.Charactors, fs=fs)


    device = "cpu"

    Pre_trained_control_filter_ID_pridector = Control_filter_Index_predictor_CNN(MODEL_PATH=MODEL_PTH
                                                                                      , device=device
                                                                                      , filter_training_noise=Charactors
                                                                                      , fs=fs)

    Primary_noise = Casting_multiple_time_length_of_primary_noise(Primary_noise, fs=fs)

    Id_vector = Pre_trained_control_filter_ID_pridector.predic_ID_vector(Primary_noise)

    return Id_vector

