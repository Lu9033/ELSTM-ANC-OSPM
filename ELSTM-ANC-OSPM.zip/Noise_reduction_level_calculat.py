import  numpy as np 
import torch
def NR_level_compute(Disturbance, Error):
    Disturbance = Disturbance.numpy()
    if not isinstance(Error, np.ndarray):
        # 如果不是，则将其转换为NumPy数组
        Error = np.array(Error)
    Power_dis = 10*np.log10(np.var(Disturbance))
    Power_err = 10*np.log10(np.var(Error))
    Nr_level  = Power_dis - Power_err
    return Nr_level

if __name__ == "__main__":
    # Re = np.random.rand(32)
    # Di = np.random.rand(32)
    Re = torch.randn(16000)
    Di = torch.randn(16000)
    Nr = NR_level_compute(Di,Re)
    print(f'the noise reduction level is {Nr} dB !!')
    
    pass 