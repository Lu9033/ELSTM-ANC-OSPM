import os
import pandas as pd
import torch
import torchaudio
import scipy.io as sio
import torch.nn.functional as F
torch.backends.cudnn.enabled = True
torch.backends.cudnn.deterministic = True

def minmaxscaler(data):
    min = data.min()
    max = data.max()
    return (data)/(max-min)

class Read_X_n:
    def __init__(self, folder, annotations_file="Index.csv"):
        self.folder = folder
        self.annotations_file = pd.read_csv(os.path.join(folder, annotations_file))

    def __len__(self):
        return len(self.annotations_file)

    def __getitem__(self, index):
        audio_sample_path = self.__get_audio_sample_path__(index)
        signal, _ = torchaudio.load(os.path.join(self.folder, audio_sample_path))
        signal = minmaxscaler(signal)
        return signal.squeeze()

    def __get_audio_sample_path__(self, index):
        path = self.annotations_file.iloc[index, 1]
        return path

class Read_Y_n:
    def __init__(self, folder, flag, annotations_file="Index.csv"):
        self.is_Yn = flag
        self.folder = folder
        self.annotations_file = pd.read_csv(os.path.join(folder, annotations_file))

    def __len__(self):
        return len(self.annotations_file)

    def __getitem__(self, index):
        audio_sample_path = self.__get_audio_sample_path__(index)
        signal, _ = torchaudio.load(os.path.join(self.folder, audio_sample_path))
        signal = minmaxscaler(signal)
        return signal.squeeze()

    def __get_audio_sample_path__(self, index):
        path = self.annotations_file.iloc[index, self.is_Yn]
        return path

class Read_Sz:
    def __init__(self, mat_file):
        self.mat_contents = sio.loadmat(mat_file)
    def __get_Sz__(self, index):
        Sz = self.mat_contents['S'][:,index]
        return Sz
    def __len__(self):
        return len(self.mat_contents['S'][0,:])

class DatasetSheet:
    def __init__(self, folder, filename):
        self.filename = filename
        self.folder = folder
        try:
            os.mkdir(folder, 755)
        except:
            print("folder exists")
        self.path = os.path.join(folder, filename)

    def add_data_to_file(self, wave_file, class_ID):
        dict = {'File_path': [wave_file], 'Class_ID': [class_ID]}
        df = pd.DataFrame(dict)

        with open(self.path, mode='a') as f:
            df.to_csv(f, header=f.tell() == 0)

    def flush(self):
        dc = pd.read_csv(self.path, index_col=0)
        # dc.index = range(len(dc))
        dc.reset_index(drop=True, inplace=True)
        dc.to_csv(self.path)

def create_dataset(folder, filename, Xn_folder, Sz_file, fs=16000):
    datasheet = DatasetSheet(folder, filename)
    Xn = Read_X_n(Xn_folder)
    Sz = Read_Sz(Sz_file)

    len_Xn = Xn.__len__()
    len_Sz = Sz.__len__()

    try:
        os.mkdir(folder)
    except:
        print("folder exists\n")

    import tqdm
    progress_bar = tqdm.tqdm(total=(len_Sz*len_Xn), desc="处理音频样本")

    NUM = 0
    for k in range(len_Sz):
        single_Sz = Sz.__get_Sz__(k)
        single_Sz = torch.from_numpy(single_Sz).type(torch.float32)
        kernel_size = single_Sz.shape[-1]
        padding = (kernel_size - 1) // 2 + 1

        for ii in range(len_Xn):

            single_Xn = Xn.__getitem__(ii)
            single_Xn_path = Xn.__get_audio_sample_path__(ii)

            with torch.no_grad():
                single_Yn = F.conv1d(single_Xn.reshape(1, 1, -1), single_Sz.reshape(1, 1, -1), stride=1, padding=padding)

            single_Yn = single_Yn.reshape(-1)
            if len(single_Yn) > 16000:
                single_Yn = single_Yn[:16000]
            elif len(single_Yn) < 16000:
                raise ValueError("长度小于16000")

            single_Yn = single_Yn.type(torch.float32).reshape(1, -1)
            filename_Yn = f'Yn_' + f'Xn{ii + k * len_Xn}' + f'Sz.wav'
            filePath_Yn = os.path.join(folder, filename_Yn)
            torchaudio.save(filePath_Yn, single_Yn, fs)

            filename_Xn = single_Xn_path
            filePath_Xn = os.path.join("../" + Xn_folder + "\\", filename_Xn)
            datasheet.add_data_to_file(filePath_Xn, filename_Yn)

            progress_bar.update(1)

            NUM += 1
            if NUM == 5000:
                datasheet.flush()
                NUM = 0

    progress_bar.close()


if __name__ == "__main__":
    # folder = ["Validate_data_40Sz", "Train_data_40Sz", "Test_data_40Sz"]
    # filename = "Index.csv"
    # Xn_folder = ['X_n_validate_40Sz', 'X_n_train_40Sz', 'X_n_test_40Sz']
    # Sz_file = "Sz_40.mat"
    #
    # for TYPE in range(0, 3):
    #     print(f"\n--------------------------STRAT CREATE:{folder[TYPE]}--------------------------")
    #     create_dataset(folder[TYPE],filename,Xn_folder[TYPE], Sz_file)
    #     print(f"--------------------------{folder[TYPE]} CREATED!!!!!--------------------------")
    create_dataset("Train_data_10Sz","Index.csv", 'X_n_train_10Sz', "Sz_10.mat")