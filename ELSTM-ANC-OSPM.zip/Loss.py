import numpy as np
import torch


def calculate_loss(ys_pred, ys_true):
    """
    计算DNN-Based Secondary Path的损失函数。

    参数:
    ys_pred -- DNN预测的反噪声信号，PyTorch张量。
    ys_true -- 实际的反噪声信号，PyTorch张量。

    返回:
    loss -- 计算得到的损失值，PyTorch标量。
    """
    # 确保输入是PyTorch张量
    ys_pred = torch.tensor(ys_pred) if isinstance(ys_pred, np.ndarray) else ys_pred
    ys_true = torch.tensor(ys_true) if isinstance(ys_true, np.ndarray) else ys_true

    # 计算预测值和真实值之间的差的平方和
    error_squared_sum = torch.sum((ys_pred - ys_true) ** 2)

    # 计算真实值的平方和
    true_squared_sum = torch.sum(ys_true ** 2)

    # 防止除以0的错误
    if true_squared_sum == 0:
        raise ValueError("真实值的平方和不能为0，这会导致除以0的错误。")

    # 计算损失函数的值
    loss = 10 * torch.log10(error_squared_sum / true_squared_sum)

    return loss