import math
import os.path
import random

import pandas as pd
import torch
import numpy as np
import torch.optim as optim
import scipy.signal as signal
import progressbar
from matplotlib import pyplot as plt
import scipy.io as sio
from torchvision.transforms.functional import to_tensor
import tqdm


from Noise_reduction_level_calculat import NR_level_compute
from Reading_path_tst import loading_paths_from_MAT, Read_X_n
from SoundGenerator import rasd_noise, k_distribution, gaussian_mixture_noise, chaotic_noise, gauss_noise, Noise_type, \
    noise_generator_select


def additional_noise_to_wav(snr_db=None, speech=None):
    if snr_db == None:
        noisy_speech = speech
    else:
        N     = len(speech)
        noise = np.random.randn(N)
        snr   = math.exp(snr_db / 10)
        speech_power = np.var(speech)
        noise_power  = np.var(noise)
        scale = np.sqrt(snr * noise_power / speech_power)
        noisy_speech = speech + noise/scale
    return noisy_speech

# ------------------------------------------------------------------------------
# Class: FxLMS algorithm
# ------------------------------------------------------------------------------
def Disturbance_reference_generation_gauss(noise_type):
    # Defined the configuration for the ANC system
    fs = 16000  # The system sampling rate
    T = 10  # The duraiton of the simulation
    t = np.arange(0, T, 1 / fs).reshape(-1, 1)

    # if noise_type == 0:
    #     Re = gaussian_mixture_noise(len(t))
    #     Re = np.array(Re)
    # elif noise_type == 1:
    #     Re = rasd_noise(len(t))
    #     Re = np.array(Re)
    # elif noise_type == 2:
    #     Re = chaotic_noise(len(t))
    #     Re = np.array(Re)
    # elif noise_type == 3:
    #     Re = k_distribution(len(t))
    #     Re = np.array(Re)
    # elif noise_type == 4:
    #     Re = gauss_noise(len(t))
    #     Re = np.array(Re)
    # else:
    #     raise ValueError("noise_type should in range 0-4!")
    f_vector = [[20, 550], [450, 1200], [1000, 2700], [2500, 4500], [4400, 7979]]
    b2 = signal.firwin(1024, f_vector[noise_type], pass_zero='bandpass', window='hamming', fs=fs)

    generator = Noise_type()
    Re = noise_generator_select(flag=4, generation=generator, f_star=20, Bandwidth=7979, fs=16000, N=T * fs)
    Pri_path, Secon_path = loading_paths_from_MAT(Sec_path_file_name='Sz_unknown.mat')
    Re = signal.lfilter(b2, 1, Re)
    # Construting the desired signal
    Dir, Fx = signal.lfilter(Pri_path, 1, Re), signal.lfilter(Secon_path, 1, Re)

    return torch.from_numpy(Dir).type(torch.float), torch.from_numpy(Fx).type(torch.float)
def Disturbance_reference_generation(noise_type):
    # Defined the configuration for the ANC system
    fs = 16000  # The system sampling rate
    T = 10  # The duraiton of the simulation
    t = np.arange(0, T, 1 / fs).reshape(-1, 1)

    # if noise_type == 0:
    #     Re = gaussian_mixture_noise(len(t))
    #     Re = np.array(Re)
    # elif noise_type == 1:
    #     Re = rasd_noise(len(t))
    #     Re = np.array(Re)
    # elif noise_type == 2:
    #     Re = chaotic_noise(len(t))
    #     Re = np.array(Re)
    # elif noise_type == 3:
    #     Re = k_distribution(len(t))
    #     Re = np.array(Re)
    # elif noise_type == 4:
    #     Re = gauss_noise(len(t))
    #     Re = np.array(Re)
    # else:
    #     raise ValueError("noise_type should in range 0-4!")
    # f_vector = [[20, 550], [450, 1200], [1000, 2700], [2500, 4500], [4400, 7980]]
    # b2 = signal.firwin(1024, f_vector[noise_type], pass_zero='bandpass', window='hamming', fs=fs)

    generator = Noise_type()
    Re = noise_generator_select(flag=noise_type, generation=generator, f_star=20, Bandwidth=7980, fs=16000, N = T * fs)
    Pri_path, Secon_path = loading_paths_from_MAT(Sec_path_file_name='Sz_unknown.mat')
    # Re = signal.lfilter(b2, 1, Re)
    # Construting the desired signal
    Dir, Fx = signal.lfilter(Pri_path, 1, Re), signal.lfilter(Secon_path, 1, Re)

    return torch.from_numpy(Dir).type(torch.float), torch.from_numpy(Fx).type(torch.float)
# ------------------------------------------------------------------------------
# Class: FxLMS algorithm
# ------------------------------------------------------------------------------
class FxMCC_algroithm():

    def __init__(self, Len,sigma):
        self.e = None
        self.sigma = sigma
        self.Wc = torch.zeros(1, Len, requires_grad=True, dtype=torch.float)
        self.Xd = torch.zeros(1, Len, dtype=torch.float)

    def feedforward(self, Xf):
        self.Xd = torch.roll(self.Xd, 1, 1)
        self.Xd[0, 0] = Xf
        yt = self.Wc @ self.Xd.t()  # .t() --->  转置
        return yt

    def LossFunction(self, y, d):
        self.e = d - y
        gauss_e = -((self.e ** 2) / (2 * (self.sigma ** 2)))
        mcc_e = - torch.exp(gauss_e)
        # k = self.e ** 2 + 1
        return mcc_e, self.e

    def _get_coeff_(self):
        return self.Wc.detach().numpy()

class FxLMS_algroithm():

    def __init__(self, Len):
        self.e = None
        self.Wc = torch.zeros(1, Len, requires_grad=True, dtype=torch.float)
        self.Xd = torch.zeros(1, Len, dtype=torch.float)

    def feedforward(self, Xf):
        self.Xd = torch.roll(self.Xd, 1, 1)
        self.Xd[0, 0] = Xf
        yt = self.Wc @ self.Xd.t()  # .t() --->  转置
        return yt

    def LossFunction(self, y, d):
        self.e = d - y
        return self.e**2, self.e

    def _get_coeff_(self):
        return self.Wc.detach().numpy()
# ------------------------------------------------------------------------------
# Function : train_fxlms_algorithm() 0.00000005
# ------------------------------------------------------------------------------
def train_fxlms_algorithm(Model, Ref, Disturbance, Stepsize=0.0001):

    # Stepsize = 0.00000005
    optimizer = optim.SGD([Model.Wc], lr=Stepsize)

    Erro_signal = []
    try_y = []
    len_data = Disturbance.shape[0]
    for itera in range(len_data):
        if itera == len_data - 1:
            k = 1
        # Feedfoward
        xin = Ref[itera]
        dis = Disturbance[itera]
        y = Model.feedforward(xin)
        loss, e = Model.LossFunction(y, dis)

        # Backward
        optimizer.zero_grad()
        loss.backward()
        optimizer.step()
        Erro_signal.append(e.item())

        # try_y.append(y.item())
        # Progress shown
    return np.array(Erro_signal)


# ------------------------------------------------------------
# Function : Generating the testing bordband noise
# ------------------------------------------------------------
def Generating_boardband_noise_wavefrom_tensor(Wc_F, Seconds, fs):
    filter_len = 1024
    bandpass_filter = signal.firwin(filter_len, Wc_F, pass_zero='bandpass', window='hamming', fs=fs)
    N = filter_len + Seconds * fs
    xin = rasd_noise(N)
    xin = np.array(xin)
    y = signal.lfilter(bandpass_filter, 1, xin)
    yout = y[filter_len:]
    # Standarlize
    yout = yout / np.sqrt(np.var(yout))
    # return a tensor of [1 x sample rate]
    return torch.from_numpy(yout).type(torch.float).unsqueeze(0)

# ------------------------------------------------------------------------------
def crear_Re_from_folder(T, folder, noise_type):
    Xn = Read_X_n(folder=folder)
    Noise = np.array([])
    len = int(Xn.__len__() / 5)
    for ii in range(0, T):
        Re = Xn.__getitem__(random.randint(noise_type*len, (noise_type+1)*len-1))
        Noise = np.concatenate((Noise, Re.reshape(-1)), axis=0)

    return torch.from_numpy(Noise).type(torch.float)
def DistDisturbance_reference_generation_from_Fvector(fs, T, noise_type, f_vector, Pri_path, Sec_path):
    """
    Pri_path and Sec_path are  One dimension arraies
    """
    # ANC platform configuration
    # t = np.arange(0, T, 1 / fs).reshape(-1, 1)
    # len_f = 1024
    # # b2    = signal.firwin(len_f, [f_vector[0],f_vector[1]], pass_zero='bandpass', window ='hamming',fs=fs)
    # b2 = signal.firwin(len_f, [20, 1000], pass_zero='bandpass', window='hamming', fs=fs)
    # if   noise_type == 0:
    #     Re = gaussian_mixture_noise(len(t))
    #     Re = np.array(Re)
    # elif noise_type == 1:
    #     Re = rasd_noise(len(t))
    #     Re = np.array(Re)
    # elif noise_type == 2:
    #     Re = chaotic_noise(len(t))
    #     Re = np.array(Re)
    # elif noise_type == 3:
    #     Re = k_distribution(len(t))
    #     Re = np.array(Re)
    # elif noise_type == 4:
    #     Re = gauss_noise(len(t))
    #     Re = np.array(Re)
    # else:
    #     raise ValueError("noise_type should in range 0-4!")
    #
    # Re = crear_Re_from_folder(T, "D:\LSTM_Proj\Sz_Predict_CRN\X_n_test_40Sz", noise_type=noise_type)
    #
    # Re = signal.lfilter(b2, 1, Re)
    #
    # Noise = Re[len_f - 1:]
    generator = Noise_type()
    Noise = noise_generator_select(flag=noise_type, generation=generator, f_star=20, Bandwidth=980, fs=16000, N=T * fs)
    # Construting the desired signal
    Dir, Fx = signal.lfilter(Pri_path, 1, Noise), signal.lfilter(Sec_path, 1, Noise)

    return torch.from_numpy(Dir).type(torch.float), torch.from_numpy(Fx).type(torch.float)


class Fixed_filter_controller():
    def __init__(self, MAT_FILE, fs):
        self.Wc = self.Load_Pretrained_filters_to_tensor(MAT_FILE)
        Len = self.Wc.shape[1]
        self.fs = fs
        self.Xd = torch.zeros(1, Len, dtype=torch.float)
        self.Current_Filter = torch.zeros(1, Len, dtype=torch.float)

    def noise_cancellation(self, Dis, Fx, filter_index):
        Erro = torch.zeros(Dis.shape[0])
        j = 0
        for ii, dis in enumerate(Dis):
            self.Xd = torch.roll(self.Xd, 1, 1)
            self.Xd[0, 0] = Fx[ii]
            yt = self.Current_Filter @ self.Xd.t()
            Erro[ii] = dis - yt
            if (ii + 1) % self.fs == 0:
                self.Current_Filter = self.Wc[filter_index[j]]
                j += 1
        return Erro

    def Load_Pretrained_filters_to_tensor(self, MAT_FILE):
        mat_contents = sio.loadmat(MAT_FILE)
        Wc_vectors = mat_contents['Wc_v']
        return torch.from_numpy(Wc_vectors).type(torch.float)


if __name__ == "__main__":
    # LIST = ['gaussian_mixture_noise','rasd_noise','chaotic_noise','k_distribution','gauss_noise']
    # LIST = [[20, 550], [450, 1200], [1000, 2700],[2500, 4500],[4400, 7980]]
    LIST = ['20-550', '450-1200', '1000-2700', '2500-4500', '4400-7980']
    for k in range(0,5):
        NR = []
        progress_bar = tqdm.tqdm(total=100, desc="Training Progress")
        for ii in range(1,101,1):
            # dis, fx = Disturbance_reference_generation(noise_type=k)
            dis, fx = Disturbance_reference_generation_gauss(noise_type=k)
            controller = FxMCC_algroithm(Len = 1024, sigma = ii / 100)
            Erro = train_fxlms_algorithm(Model = controller, Ref = fx, Disturbance = dis)
            Nr = NR_level_compute(dis, Erro)
            progress_bar.update(1)
            NR.append(Nr.item())
        df = pd.DataFrame(NR)
        df.to_csv(LIST[k] + '.csv', index=False)
        print(f"DATA SAVED AT {LIST[k] + '.csv'}")
        progress_bar.close()
