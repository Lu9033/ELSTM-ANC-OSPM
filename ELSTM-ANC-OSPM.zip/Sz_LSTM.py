from torch import nn


class Sz_LSTM(nn.Module):

    def __init__(self, input_size = 1000, hidden_size = 1000, output_size = 256, num_layers=1, dropout_pro=0.2):
        super().__init__()
        self.lstm1 = nn.LSTM(input_size=input_size, hidden_size=hidden_size, num_layers=num_layers, dropout=dropout_pro)
        self.lstm2 = nn.LSTM(input_size=hidden_size, hidden_size=hidden_size, num_layers=num_layers, dropout=dropout_pro)
        self.relu = nn.Tanh()
        self.dropout = nn.Dropout(dropout_pro)
        #
        # # 定义卷积层、批归一化和激活函数
        self.conv_layers = nn.Sequential(
            # 卷积层1：输入通道数为1，输出通道数64，kernel大小3，stride=1，padding=1
            nn.Conv1d(in_channels=1, out_channels=32, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm1d(num_features=32),
            nn.ReLU(),

            # 下采样层1：最大池化，kernel大小2，stride=2
            nn.MaxPool1d(kernel_size=2, stride=2),

            # 卷积层2：输入通道数64，输出通道数128
            nn.Conv1d(in_channels=32, out_channels=32, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm1d(num_features=32),
            nn.ReLU(),

            # 下采样层2：最大池化，kernel大小2，stride=2
            nn.MaxPool1d(kernel_size=2, stride=2),

            # 卷积层3：输入通道数128，输出通道数256
            nn.Conv1d(in_channels=32, out_channels=16, kernel_size=3, stride=1, padding=1),
            nn.BatchNorm1d(num_features=16),
            nn.ReLU(),

            # 下采样层3：最大池化，kernel大小2，stride=2
            nn.MaxPool1d(kernel_size=2, stride=2),

        )

        # 确保经过所有卷积和池化操作后输出的长度为output_size
        self.fc_layers = nn.Sequential(
            # 最后的全连接层将输入从二维转换为一维，并应用线性变换
            nn.Linear(in_features=2000, out_features=output_size, bias=True)
        )

    def forward(self, input):
        b, s, h = input.shape
        input = input.reshape(s, b, h)
        x, _ = self.lstm1(input)  # _x is input, size (seq_len, batch, input_size)
        # x = self.fc(x)
        x = self.relu(x)
        x = self.dropout(x)
        x, _ = self.lstm2(x)
        # x = self.softmax(x)
        x = x.view(b, s, -1)  # 把形状改回来
        x = self.conv_layers(x)
        x = self.fc_layers(x.reshape(b,-1))

        return x.reshape(b, s, -1)


if __name__ == "__main__":
    Paper_LSTM = Sz_LSTM()
    print(f"LSTM:{Paper_LSTM}")