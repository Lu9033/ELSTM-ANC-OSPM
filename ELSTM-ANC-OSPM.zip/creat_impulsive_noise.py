import os
import pandas as pd
import tqdm
from SoundGenerator import noise_generator


class DatasetSheet:

    def __init__(self, folder, filename):
        self.filename = filename
        self.folder = folder
        try:
            os.mkdir(folder, 755)
        except:
            print("folder exists")
        self.path = os.path.join(folder, filename)

    def add_data_to_file(self, wave_file, class_ID):
        dict = {'File_path': [wave_file], 'Class_ID': [class_ID]}
        df = pd.DataFrame(dict)

        with open(self.path, mode='a') as f:
            df.to_csv(f, header=f.tell() == 0)

    def flush(self):
        dc = pd.read_csv(self.path, index_col=0)
        dc.index = range(len(dc))
        dc.to_csv(self.path)


if __name__ == '__main__':

    file_name = "Index.csv"
    Folder_name = 'Train_data_test'
    N_sample_each_class = 2000
    datasheet = DatasetSheet(Folder_name, file_name)
    Fre_noise_vector = [20, 1000]

    progress_bar = tqdm.tqdm(total=5*N_sample_each_class, desc="Progress")
    for ii in range(0, 5):
        Generator = noise_generator(type=ii, fs=16000, folder=Folder_name)
        Fre_target_element = ii

        for kk in range(N_sample_each_class):
            progress_bar.update(1)
            filePath = Generator.__balance_construct__(Fre_noise_vector=Fre_noise_vector)
            datasheet.add_data_to_file(filePath, Fre_target_element)

            if kk % 1000 == 0:
                datasheet.flush()