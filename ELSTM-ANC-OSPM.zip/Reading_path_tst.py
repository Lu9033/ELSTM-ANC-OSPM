import os
import pandas as pd
import scipy.io as sio
import torchaudio

from dataloader import minmaxscaler
def loading_paths_from_MAT(folder = 'Pz and Sz'
                           ,subfolder = 'measured'
                           ,Pri_path_file_name = 'Pz1.mat'
                           ,Sec_path_file_name ='Sz.mat'):
    Primay_path_file, Secondary_path_file = os.path.join(folder, subfolder, Pri_path_file_name), os.path.join(folder,subfolder, Sec_path_file_name)
    Pri_dfs, Secon_dfs = sio.loadmat(Primay_path_file), sio.loadmat(Secondary_path_file)
    Pri_path, Secon_path = Pri_dfs['Pz1'].squeeze(), Secon_dfs['S'].squeeze()
    return Pri_path, Secon_path

class Read_Sz:
    def __init__(self, mat_file):
        self.mat_contents = sio.loadmat(mat_file)

    def __get_Sz__(self, index):
        Sz = self.mat_contents['S'][:, index]
        return Sz

    def __len__(self):
        return len(self.mat_contents['S'][0, :])


class Read_Y_n:
    def __init__(self, folder, flag, annotations_file="Index.csv"):
        self.is_Yn = flag
        self.folder = folder
        self.annotations_file = pd.read_csv(os.path.join(folder, annotations_file))

    def __len__(self):
        return len(self.annotations_file)

    def __getitem__(self, index):
        audio_sample_path = self.__get_audio_sample_path__(index)
        signal, _ = torchaudio.load(os.path.join(self.folder, audio_sample_path))
        signal = minmaxscaler(signal)
        return signal.squeeze()

    def __get_audio_sample_path__(self, index):
        path = self.annotations_file.iloc[index, self.is_Yn]
        return path

class Read_X_n:
    def __init__(self, folder, annotations_file="Index.csv"):
        self.folder = folder
        self.annotations_file = pd.read_csv(os.path.join(folder, annotations_file))

    def __len__(self):
        return len(self.annotations_file)

    def __getitem__(self, index):
        audio_sample_path = self.__get_audio_sample_path__(index)
        signal, _ = torchaudio.load(os.path.join(self.folder, audio_sample_path))
        signal = minmaxscaler(signal)
        return signal.squeeze()

    def __get_audio_sample_path__(self, index):
        path = self.annotations_file.iloc[index, 1]
        return path




if __name__=="__main__":

    MAT_FILE = os.path.join('Pz and Sz', 'measured','Pz1.mat')
    print(MAT_FILE)
    mat_contents    = sio.loadmat(MAT_FILE)
    Wc_vectors      = mat_contents['Pz1']
    Wc_vectors      = Wc_vectors.squeeze(1)
    print(Wc_vectors.shape)
