The ELSTM-ANC-OSPM include two parts:ELSTM(MyLSTM folder) and Hybrid LSTM-CNN(Sz_Predict_CRN folder)

·In MyLSTM folder:
creat_inpulsive_noise.py to generate dataset.
Train_LSTM.py to train the LSTM.
ANC_SzPredict.py a simulation of the ELSTM-ANC-OSPM algorithm.

·In Sz_Predict_CRN folder:
creat_Yn.py to creat the dataset.
train_lstm_2.py to train the hybrid LSTM-CNN.
Sz_compare.py a simulation of the performance of the propsed online secondary path model algorithm.
Matlab\\GenerateSz.m is used to creat secondary paths

