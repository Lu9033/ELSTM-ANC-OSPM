import torch
from torch import nn
from torch.utils.data import DataLoader


def create_data_loader(train_data, batch_size):
    train_dataloader = DataLoader(train_data, batch_size)
    return train_dataloader

class LSTM(nn.Module):

    def __init__(self, input_size = 100, hidden_size = 10, output_size = 5, num_layers=1, dropout_pro=0.2):
        super().__init__()
        self.lstm1 = nn.LSTM(input_size=input_size, hidden_size=hidden_size, num_layers=num_layers, dropout=dropout_pro, batch_first=True, )
        # self.lstm2 = nn.LSTM(input_size=hidden_size, hidden_size=100, num_layers=num_layers, dropout=dropout_pro, batch_first=True)
        self.normalized = nn.BatchNorm1d(num_features=160)
        # self.normalized2 = nn.BatchNorm1d(num_features=20)
        self.fc1 = nn.Linear(in_features=1600, out_features=5)
        # self.fc2 = nn.Linear(in_features=10, out_features=5)
        self.softmax = nn.Softmax(dim=1)
        self.dropout = nn.Dropout(dropout_pro)
        self.relu = nn.ReLU()


    def forward(self, input):
        b, s, h = input.shape

        input = input.reshape(b, 160, -1)

        x, _ = self.lstm1(input)
        x = self.dropout(x)
        x = self.relu(x)
        x = self.normalized(x)

        x = self.fc1(x.reshape(b, -1))
        # x = self.relu(x)
        # x = self.fc2(x)

        x = self.softmax(x)
        return x


if __name__ == "__main__":
    if torch.cuda.is_available():
        device = "cuda"
    else:
        device = "cpu"
    print(f"Using {device}")

    MyLSTM = LSTM()
    print(MyLSTM)




