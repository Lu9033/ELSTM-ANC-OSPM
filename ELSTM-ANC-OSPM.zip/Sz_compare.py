import random
import matplotlib.pyplot as plt
import numpy as np
import torch
from matplotlib.pyplot import figure
from scipy.io import savemat

from LSTM import LSTM, LSTM_CNN
from Sz_pre_traditional_method import predict_Sz_with_Fxlms
from create_Yn import Read_Sz, Read_Y_n
from spect_plot import power_plot, mse_plot

import warnings
warnings.filterwarnings("ignore")

def load_weigth_for_model(model, pretrained_path, device):
    model_dict = model.state_dict()
    pretrained_dict = torch.load(pretrained_path, map_location=device)

    for k, v in model_dict.items():
        model_dict[k] = pretrained_dict[k]

    model.load_state_dict(model_dict)

if __name__ == "__main__":
    MODEL_PATH_LSTM_CNN = 'Sz_predict_CRN_40Sz.pth'
    MODEL_PATH_LSTM = "Sz_predict_LSTM_40Sz.pth"
    device = 'cpu'
    lstm_cnn = LSTM_CNN().to(device)
    lstm = LSTM().to(device)
    load_weigth_for_model(lstm_cnn, MODEL_PATH_LSTM_CNN, device)
    load_weigth_for_model(lstm, MODEL_PATH_LSTM, device)

    Yn = Read_Y_n(folder="Test_data_40Sz", flag=2)
    Xn = Read_Y_n(folder="Test_data_40Sz", flag=1)
    Sz = Read_Sz(mat_file="Sz_40.mat")
    len_Yn = Yn.__len__()
    signal_choose = random.randint(0, len_Yn)
    # signal_choose = 269786
    print(f"\n----------SELECTED SIGNAL:{signal_choose}\t{Xn.__get_audio_sample_path__(signal_choose)}\t{Yn.__get_audio_sample_path__(signal_choose)}----------")
    single_Sz = Sz.__get_Sz__(int(signal_choose/(len_Yn/Sz.__len__())))
    Xn, Yn =  Xn.__getitem__(signal_choose), Yn.__getitem__(signal_choose)
    Xn_nn, Yn_nn = Xn[:1000], Yn[:1000]

    with torch.no_grad():
        predicted_Sz_lstm_cnn = lstm_cnn(Yn_nn.reshape(1,1,-1))
        predicted_Sz_lstm = lstm(Yn_nn.reshape(1, 1, -1))
    predicted_Sz_lstm_cnn = predicted_Sz_lstm_cnn.detach().to('cpu')
    predicted_Sz_lstm = predicted_Sz_lstm.detach().to('cpu')
    predicted_Sz_lsm_tradition = predict_Sz_with_Fxlms(Xn, Yn)


    ###################################################################################################################
    # SAVE
    mdict = {'single_Sz': single_Sz, 'predicted_Sz_lstm_cnn': predicted_Sz_lstm_cnn.reshape(-1),
             'predicted_Sz_lstm': predicted_Sz_lstm.reshape(-1), 'predicted_Sz_lsm_tradition': predicted_Sz_lsm_tradition.reshape(-1)}
    FILE_NAME_PATH = 'Sz_identification_drawing.mat'
    savemat(FILE_NAME_PATH, mdict)
    ###################################################################################################################
    # Magnitude
    figure(3)
    plt.plot(single_Sz, label = "Sz")
    plt.plot(predicted_Sz_lstm_cnn.reshape(-1), label = "LSTM+CNN predict Sz")
    plt.plot(predicted_Sz_lstm.reshape(-1), label="LSTM predict Sz")
    plt.plot(predicted_Sz_lsm_tradition.reshape(-1), label = "Traditional LMS predict Sz")
    plt.legend()
    plt.title("(a)")
    plt.xlabel('Taps')
    plt.ylabel('Magnitude')

    ###################################################################################################################
    # POWER
    figure(2)
    [Pxx1, f1] = plt.psd(single_Sz.reshape(-1),  # 随机信号
                         NFFT=4096,  # 每个窗的长度
                         Fs=16000,  # 采样频率
                         detrend='mean',  # 去掉均值
                         window=np.hanning(4096),  # 加汉尼窗
                         noverlap=int(4096 * 3 / 4),  # 每个窗重叠75%的数据
                         sides='twosided')  # 求双边谱
    [Pxx1, f1] = plt.psd(predicted_Sz_lstm_cnn.reshape(-1),  # 随机信号
                         NFFT=4096,  # 每个窗的长度
                         Fs=16000,  # 采样频率
                         detrend='mean',  # 去掉均值
                         window=np.hanning(4096),  # 加汉尼窗
                         noverlap=int(4096 * 3 / 4),  # 每个窗重叠75%的数据
                         sides='twosided')  # 求双边谱
    [Pxx1, f1] = plt.psd(predicted_Sz_lstm.reshape(-1),  # 随机信号
                         NFFT=4096,  # 每个窗的长度
                         Fs=16000,  # 采样频率
                         detrend='mean',  # 去掉均值
                         window=np.hanning(4096),  # 加汉尼窗
                         noverlap=int(4096 * 3 / 4),  # 每个窗重叠75%的数据
                         sides='twosided')  # 求双边谱
    [Pxx1, f1] = plt.psd(predicted_Sz_lsm_tradition.reshape(-1),  # 随机信号
                         NFFT=4096,  # 每个窗的长度
                         Fs=16000,  # 采样频率
                         detrend='mean',  # 去掉均值
                         window=np.hanning(4096),  # 加汉尼窗
                         noverlap=int(4096 * 3 / 4),  # 每个窗重叠75%的数据
                         sides='twosided')  # 求双边谱
    plt.title("(b)")
    plt.xlabel('Frequency (Hz)')
    plt.ylabel('Power spectral density (dB/Hz)')
    ##################################################################################################################
    # MSE
    figure(1)
    single_Sz = torch.from_numpy(single_Sz)
    plt.plot(10 * torch.log10((single_Sz - predicted_Sz_lstm_cnn.reshape(-1)) ** 2), label = "LSTM+CNN predict Sz", color = 'y')
    plt.plot(10 * torch.log10((single_Sz - predicted_Sz_lstm.reshape(-1)) ** 2), label="LSTM predict Sz", color = 'g')
    plt.plot(10 * torch.log10((single_Sz - predicted_Sz_lsm_tradition.reshape(-1)) ** 2), label = "Traditional LMS predict Sz", color = 'r')
    plt.legend()
    plt.title("(c)")
    plt.xlabel('Taps')
    plt.ylabel('MSE (dB)')

    plt.show()
















