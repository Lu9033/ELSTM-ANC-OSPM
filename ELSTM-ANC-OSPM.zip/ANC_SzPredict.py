import matplotlib
import torch.nn.functional as F
import random
import time
import torch
from matplotlib.pyplot import figure
from scipy import signal
from scipy.io import savemat

from Noise_reduction_level_calculat import NR_level_compute
from Pre_trianing_control_filters import Fxied_filters
from Predictor import Control_filter_Index_predictor_LSTM
from Reading_path_tst import loading_paths_from_MAT, Read_Sz, Read_Y_n, Read_X_n
import matplotlib.pyplot as plt
from FxMCC_algroithm import FxMCC_algroithm, train_fxlms_algorithm, Fixed_filter_controller, FxLMS_algroithm
import numpy as np
from SoundGenerator import rasd_noise, gauss_noise, k_distribution, chaotic_noise, gaussian_mixture_noise, \
    noise_generator_select, Noise_type
import scipy.io as sio
import warnings

from Sz_LSTM import Sz_LSTM
from dataloader import minmaxscaler
from lstm_pre import load_weigth_for_model

warnings.filterwarnings("ignore")


def distrubance_reference_generation_from_Fvector(fs, T, f_vector, Pri_path, Sec_path):
    t = np.arange(0, 2, 1 / fs).reshape(-1, 1)
    len_f = 1024
    id_vector = np.array([])

    for ii in range(0, T):
        kk = random.randint(0, len(f_vector)-1)
        b2 = signal.firwin(len_f, f_vector[kk], pass_zero='bandpass', window='hamming', fs=fs)
        noise_choose = random.randint(0,4)
        # noise_choose = 3
        id_vector = np.concatenate((id_vector, np.ones(2) * noise_choose), axis=0)
        if noise_choose == 0:
            Re = gaussian_mixture_noise(len(t))
            Re = np.array(Re)
            print(" choose gauss_mixture : 0")
        elif noise_choose == 1:
            Re = rasd_noise(len(t))
            Re = np.array(Re)
            print(" choose rasd_noise : 1")
        elif noise_choose == 2:
            Re = chaotic_noise(len(t))
            Re = np.array(Re)
            print(" choose chaotic_noise : 2")
        elif noise_choose == 3:
            Re = k_distribution(len(t))
            Re = np.array(Re)
            print(" choose k_distribution : 3")
        elif noise_choose == 4:
            Re = gauss_noise(len(t))
            Re = np.array(Re)
            print(" choose gauss_noise : 4")
        else:
            raise ValueError("noise_choose should in range 0-4!")
        Re = signal.lfilter(b2, 1, Re)
        if ii == 0:
            Noise = Re
        else:
            if ii ==2 :
                Noise = np.concatenate((Noise, 4*Re),axis=0)
            else:
                 Noise = np.concatenate((Noise, Re), axis=0)
    # Construting the desired signal
    Dir, Fx = signal.lfilter(Pri_path, 1, Noise), signal.lfilter(Sec_path, 1, Noise)

    return torch.from_numpy(Dir).type(torch.float), torch.from_numpy(Fx).type(torch.float), torch.from_numpy(
        Noise).type(torch.float), id_vector

def Casting_single_time_length_of_training_noise(filter_training_noise,fs):
    assert filter_training_noise.dim() == 3, 'The dimension of the training noise should be 3 !!!'
    print(filter_training_noise[:,:,:fs].shape)
    return filter_training_noise[:,:,:fs]
def Casting_multiple_time_length_of_primary_noise(primary_noise,fs):
    assert  primary_noise.shape[0] == 1, 'The dimension of the primary noise should be [1 x samples] !!!'
    cast_len = primary_noise.shape[1] - primary_noise.shape[1]%fs
    return primary_noise[:,:cast_len]


def Control_filter_selection(MODEL_PTH, Primary_noise, Filter_mat_name, fs=16000):

    Fxied_control_filter = Fxied_filters(MATFILE_PATH=Filter_mat_name, fs=fs)

    Charactors = Casting_single_time_length_of_training_noise(Fxied_control_filter.Charactors, fs=fs)

    device = "cpu"

    Pre_trained_control_filter_ID_pridector = Control_filter_Index_predictor_LSTM(MODEL_PATH=MODEL_PTH
                                                                                      , device=device
                                                                                      , filter_training_noise=Charactors
                                                                                      , fs=fs)

    Primary_noise = Casting_multiple_time_length_of_primary_noise(Primary_noise, fs=fs)

    Id_vector = Pre_trained_control_filter_ID_pridector.predic_ID_vector(Primary_noise)

    return Id_vector

def predict_Sz(Noise, unknown_Sz):
    MODEL_PATH_LSTM = 'Sz_predict_LSTM.pth'
    device = 'cpu'
    sz_lstm = Sz_LSTM().to(device)
    load_weigth_for_model(sz_lstm, MODEL_PATH_LSTM, device)
    # unkonwm_Sz = torch.from_numpy(unkonwm_Sz).type(torch.float)

    # XN = np.convolve(Noise, unkonwm_Sz, mode='same')
    # XN = torch.from_numpy(XN).type(torch.float)
    unknown_Sz = torch.from_numpy(unknown_Sz).type(torch.float)
    # Noise = minmaxscaler(Noise.reshape(-1))
    Noise = Noise / torch.sqrt(torch.var(Noise.reshape(-1)))
    Noise = Noise[:1000]
    with torch.no_grad():
        XN = F.conv1d(Noise.reshape(1, 1, -1), unknown_Sz.reshape(1, 1, -1), stride=1, padding=128)
    XN = XN.reshape(-1)
    if len(XN) > 1000:
        XN = XN[:1000]
    elif len(XN) < 1000:
        raise ValueError("长度小于1000")


    with torch.no_grad():
        predicted_Sz = sz_lstm(XN.reshape(1, 1, -1))
    predicted_Sz = predicted_Sz.detach().to('cpu')

    return predicted_Sz.reshape(-1)

def crear_Re(fs, T, f_vector, folder):

    t = np.arange(0, 20, 1 / fs).reshape(-1, 1)
    len_f = 1024
    id_vector = np.array([])
    Yn = Read_X_n(folder=folder)

    for ii in range(0, 5*T):
        # kk = random.randint(0, len(f_vector) - 1)
        # b2 = signal.firwin(len_f, [20, 1000], pass_zero='bandpass', window='hamming', fs=fs)

        noise_choose = 4 - ii % 5
        id_vector = np.concatenate((id_vector, np.ones(int(len(t)/fs)) * noise_choose), axis=0)
        # if noise_choose == 0:
        #     Re = gaussian_mixture_noise(len(t))
        #     Re = np.array(Re)
        #     print(" choose gauss_mixture : 0")
        # elif noise_choose == 1:
        #     Re = rasd_noise(len(t))
        #     Re = np.array(Re)
        #     print(" choose rasd_noise : 1")
        # elif noise_choose == 2:
        #     Re = chaotic_noise(len(t))
        #     Re = np.array(Re)
        #     print(" choose chaotic_noise : 2")
        # elif noise_choose == 3:
        #     Re = k_distribution(len(t))
        #     Re = np.array(Re)
        #     print(" choose k_distribution : 3")
        # elif noise_choose == 4:
        #     Re = gauss_noise(len(t))
        #     Re = np.array(Re)
        #     print(" choose gauss_noise : 4")
        # else:
        #     raise ValueError("noise_choose should in range 0-4!")
        # Re = Re / np.sqrt(np.var(Re))
        # Re = signal.lfilter(b2, 1, Re)
        generator = Noise_type()
        Re = noise_generator_select(flag=noise_choose, generation=generator, f_star=20, Bandwidth=980, fs=16000, N=len(t))
        # kk = random.randint(0, len(f_vector) - 1)
        # b2 = signal.firwin(len_f, f_vector[kk], pass_zero='bandpass', window='hamming', fs=fs)
        # Re = signal.lfilter(b2, 1, Re)
        if ii == 0:
            Re = Yn.__getitem__(random.randint(noise_choose * 2000, (noise_choose + 1) * 2000 - 1))
            Noise = Re
        else:
            if ii == 2:
                Noise = np.concatenate((Noise, 2 * Re), axis=0)
            else:
                Noise = np.concatenate((Noise, Re), axis=0)

    return torch.from_numpy(Noise).type(torch.float), id_vector

def crear_Re_from_folder(T, folder, f_vector):
    Yn = Read_X_n(folder=folder)
    Noise = np.array([])
    id_vector = []
    len_f = 1024

    for ii in range(0, T*5):
        type = ii % 5
        # kk = random.randint(0, len(f_vector) - 1)
        # b2 = signal.firwin(len_f, f_vector[kk], pass_zero='bandpass', window='hamming', fs=fs)
        Re = Yn.__getitem__(random.randint(type*2000, (type+1)*2000-1))
        # Re = signal.lfilter(b2, 1, Re)
        Noise = np.concatenate((Noise, Re.reshape(-1)), axis=0)
        Noise = np.concatenate((Noise, Re.reshape(-1)), axis=0)
        Noise = np.concatenate((Noise, Re.reshape(-1)), axis=0)
        Noise = np.concatenate((Noise, Re.reshape(-1)), axis=0)
        Noise = np.concatenate((Noise, Re.reshape(-1)), axis=0)
        id_vector.append(type)
        id_vector.append(type)
        id_vector.append(type)
        id_vector.append(type)
        id_vector.append(type)
    return torch.from_numpy(Noise).type(torch.float), np.array(id_vector)

def distrubance_reference_generation_from_predict_Sz(Re, Pri_path, Sec_path):
    Dir, Fx = signal.lfilter(Pri_path, 1, Re), signal.lfilter(Sec_path, 1, Re)
    return torch.from_numpy(Dir).type(torch.float), torch.from_numpy(Fx).type(torch.float)

def distrubance_reference_generation_from_unknown_Sz(Re, Pri_path, Sec_path):
    Dir, Fx = signal.lfilter(Pri_path, 1, Re), signal.lfilter(Sec_path, 1, Re)
    return torch.from_numpy(Dir).type(torch.float), torch.from_numpy(Fx).type(torch.float)

class Fixed_filter_controller_For_Online_Sz():
    def __init__(self, MAT_FILE, fs, Sz):
        self.Wc = self.Load_Pretrained_filters_to_tensor(MAT_FILE)
        self.Len = self.Wc.shape[1]
        self.fs = fs
        self.Xd = torch.zeros(1,  self.Len, dtype=torch.float)
        self.Current_Filter = torch.zeros(1,  self.Len, dtype=torch.float)
        self.Sz = Sz
    def noise_cancellation(self, Dis, Re, filter_index):
        Erro = torch.zeros(Dis.shape[0])
        Fx = signal.lfilter(self.Sz, 1, Re)
        j = 0
        for ii, dis in enumerate(Fx):
            self.Xd = torch.roll(self.Xd, 1, 1)
            self.Xd[0, 0] = Re[ii]
            yt = self.Current_Filter @ self.Xd.t()
            Erro[ii] = dis - yt
            if (ii + 1) % self.fs == 0:
                self.Current_Filter = self.Wc[filter_index[j]]
                j += 1
        return Erro

    def Load_Pretrained_filters_to_tensor(self, MAT_FILE):
        mat_contents = sio.loadmat(MAT_FILE)
        Wc_vectors = mat_contents['Wc_v']
        return torch.from_numpy(Wc_vectors).type(torch.float)

if __name__ == '__main__':

    F_vector = [[20, 230], [200, 420], [400, 630], [600, 820], [800, 1000]]
    fs = 16000
    T = 6
    folder = "D:\LSTM_Proj\Sz_Predict_CRN\X_n_test_40Sz"
    Pri_path, _ = loading_paths_from_MAT(Sec_path_file_name='Sz.mat')
    # Sz_batch = Read_Sz('Sz_40.mat')
    # unkonwm_Sz = Sz_batch.__get_Sz__(random.randint(0, Sz_batch.__len__() - 1))
    # unkonwm_Sz  = Sz_batch.__get_Sz__(26)
    _, unkonwm_Sz = loading_paths_from_MAT(Sec_path_file_name='Sz_unknown.mat')
    # Sec_path = Sz_batch.__get_Sz__(2)
    Re, id_vector = crear_Re(fs=fs, T=T, f_vector=F_vector, folder=folder)
    # Re, id_vector = crear_Re_from_folder(T, folder,  F_vector)
    predicted_Sec_path = predict_Sz(Re, unkonwm_Sz)

    # _, Fx_LSTM = distrubance_reference_generation_from_predict_Sz(Re, Pri_path = Pri_path, Sec_path = predicted_Sec_path)
    Dis, Fx = distrubance_reference_generation_from_unknown_Sz(Re = Re, Pri_path = Pri_path, Sec_path = predicted_Sec_path)

    # =============================================================================================
    # the simulaitons of the FxMCC algorithm
    controller = FxMCC_algroithm(Len=1024, sigma=0.7)
    start_time1 = time.time()
    ErroC_MCC = train_fxlms_algorithm(Model = controller, Ref = Fx, Disturbance = Dis)
    Wc_matrix = controller._get_coeff_()
    ErroC_MCC = Dis - np.convolve(np.convolve(Re, Wc_matrix.reshape(-1), mode='same'), unkonwm_Sz, mode='same')
    end_time1 = time.time()
    elapsed_time1 = end_time1 - start_time1
    Nr = NR_level_compute(Dis, ErroC_MCC)

    print(f"FxMCC Nr: {Nr}")
    print(f"FxMCC TIME: {elapsed_time1}")

    # =============================================================================================
    # CNN learning
    FILE_NAME_PATH = 'Control_Filter_MCC.mat'
    MODEL_PTH_CNN = 'feedforwardnet_SFANC.pth'
    # ErroC_CNN = np.array([])
    trained_Wc = torch.tensor([], requires_grad=False)
    from FOR_CNN import Control_filter_selection_CNN

    start_time2 = time.time()
    id_vector_CNN = Control_filter_selection_CNN(MODEL_PTH = MODEL_PTH_CNN, Primary_noise = Re.unsqueeze(0),
                                             Filter_mat_name = FILE_NAME_PATH, fs=16000)
    Fixed_Cancellation = Fixed_filter_controller(MAT_FILE=FILE_NAME_PATH, fs=16000)

    # k = 0
    # for ii in id_vector_CNN:
    #     controller = FxLMS_algroithm(Len=1024)
    #     controller.Wc = torch.tensor(Fixed_Cancellation.Wc[ii], requires_grad=True)
    #     ErroC_CNN = np.concatenate((ErroC_CNN, train_fxlms_algorithm(controller, Ref=Fx[k*fs:(k+1)*fs], Disturbance=Dis[k*fs:(k+1)*fs])), axis=0)
    #     trained_Wc = torch.concatenate((trained_Wc, controller.Wc.reshape(-1)), dim=0)
    #     k += 1
    #
    # trained_Wc = torch.tensor(trained_Wc, requires_grad=False)
    # ErroC_CNN = Dis - np.convolve(np.convolve(Re, trained_Wc.reshape(-1), mode='same'), unkonwm_Sz, mode='same')

    ErroC_CNN = Fixed_Cancellation.noise_cancellation(Dis = Dis, Fx=Fx, filter_index = id_vector_CNN)

    end_time2 = time.time()
    elapsed_time2 = end_time2 - start_time2

    Nr = NR_level_compute(Dis, ErroC_CNN)
    print(f"CNN Nr: {Nr}")
    print(f"CNN TIME: {elapsed_time2}")

    #=============================================================================================
    # LSTM learning
    FILE_NAME_PATH = 'Control_Filter_MCC.mat'
    MODEL_PTH_LSTM = 'lstm_feedforwardnet.pth'
    # sigma_total = [0.53, 0.47, 0.06, 0.23, 0.2]
    # ErroC_LSTM = np.array([])
    # trained_Wc = torch.tensor([], requires_grad=False)

    start_time2 = time.time()
    id_vector_LSTM = Control_filter_selection(MODEL_PTH = MODEL_PTH_LSTM, Primary_noise = Re.unsqueeze(0)
                                              , Filter_mat_name = FILE_NAME_PATH, fs=16000)
    Fixed_Cancellation = Fixed_filter_controller(MAT_FILE = FILE_NAME_PATH, fs=16000)

    # k = 0
    # for ii in id_vector_LSTM:
    #     controller = FxMCC_algroithm(Len=1024, sigma=sigma_total[ii])
    #     controller.Wc = torch.tensor(Fixed_Cancellation.Wc[ii], requires_grad=True)
    #     Error = train_fxlms_algorithm(controller, Ref=Fx[k * fs:(k + 1) * fs], Disturbance=Dis[k * fs:(k + 1) * fs])
    #     # ErroC_LSTM = np.concatenate((ErroC_LSTM, Error), axis=0)
    #     # trained_Wc = torch.concatenate((trained_Wc, controller.Wc.reshape(-1)), dim=0)
    #
    #     Fixed_Cancellation.Wc[ii] = controller.Wc
    #     k += 1

    # trained_Wc = torch.tensor(trained_Wc, requires_grad=False)
    # ErroC_LSTM = Dis - np.convolve(np.convolve(Re, trained_Wc.reshape(-1), mode='same'), Sec_path, mode='same')
    ErroC_LSTM = Fixed_Cancellation.noise_cancellation(Dis = Dis, Fx=Fx, filter_index = id_vector_LSTM)

    end_time2 = time.time()
    elapsed_time2 = end_time2 - start_time2

    Nr = NR_level_compute(Dis, ErroC_LSTM)
    print(f"LSTM Nr: {Nr}")
    print(f"LSTM TIME: {elapsed_time2}")

    # =============================================================================================
    # SAVE
    mdict = {'Dis': Dis.numpy(), 'ErroC_MCC': ErroC_MCC,
             'ErroC_CNN': ErroC_CNN, 'ErroC_LSTM': ErroC_LSTM}
    FILE_NAME_PATH = 'Noise_cancellation_same_filter_drawing.mat'
    savemat(FILE_NAME_PATH, mdict)
    mdict = {'Unknown_secondary_path': unkonwm_Sz, 'Predicted_Secondary_Path': predicted_Sec_path}
    FILE_NAME_PATH = 'Noise_cancellation_same_filter_Sz_drawing.mat'
    savemat(FILE_NAME_PATH, mdict)
    # =============================================================================================
    # MAGNITUDE
    figure(1)
    Time = np.arange(len(Re.reshape(-1))) * (1 / fs)
    plt.plot(Time, Re.numpy(), label = 'NOISE')
    plt.plot(Time, ErroC_MCC, label='FxMCC')
    plt.plot(Time, ErroC_CNN, label='CNN')

    plt.plot(Time, ErroC_LSTM, label='LSTM')
    # plt.xticks(np.arange(0, T * 2, 1))
    plt.title('(a)')
    plt.xlabel('Time (seconds)')
    plt.ylabel('Magnitude')
    plt.legend(loc=1)


    # =============================================================================================
    # POWER
    figure(2)
    [Pxx1, f1] = plt.psd(Re.numpy(),  # 随机信号
                         NFFT=4096,  # 每个窗的长度
                         Fs=fs,  # 采样频率
                         detrend='mean',  # 去掉均值
                         window=np.hanning(4096),  # 加汉尼窗
                         noverlap=int(4096 * 3 / 4),  # 每个窗重叠75%的数据
                         sides='twosided')  # 求双边谱


    [Pxx1, f1] = plt.psd(ErroC_MCC,  # 随机信号
                         NFFT=4096,  # 每个窗的长度
                         Fs=fs,  # 采样频率
                         detrend='mean',  # 去掉均值
                         window=np.hanning(4096),  # 加汉尼窗
                         noverlap=int(4096 * 3 / 4),  # 每个窗重叠75%的数据
                         sides='twosided')  # 求双边谱


    [Pxx1, f1] = plt.psd(ErroC_CNN,  # 随机信号
                         NFFT=4096,  # 每个窗的长度
                         Fs=fs,  # 采样频率
                         detrend='mean',  # 去掉均值
                         window=np.hanning(4096),  # 加汉尼窗
                         noverlap=int(4096 * 3 / 4),  # 每个窗重叠75%的数据
                         sides='twosided')  # 求双边谱



    [Pxx1, f1] = plt.psd(ErroC_LSTM,  # 随机信号
                         NFFT=4096,  # 每个窗的长度
                         Fs=fs,  # 采样频率
                         detrend='mean',  # 去掉均值
                         window=np.hanning(4096),  # 加汉尼窗
                         noverlap=int(4096 * 3 / 4),  # 每个窗重叠75%的数据
                         sides='twosided')  # 求双边谱


    plt.title('(b)')
    plt.xlabel('Frequency (Hz)')
    plt.ylabel('Power spectral density (dB/Hz)')

    # =============================================================================================
    # MSE
    from scipy.ndimage import gaussian_filter1d
    sigma = 250
    figure(3)
    plt.plot(Time, gaussian_filter1d(10 * np.log10(Re.numpy()**2), sigma=sigma), label = 'NOISE')
    plt.plot(Time, gaussian_filter1d(10 * np.log10(ErroC_MCC ** 2), sigma=sigma), label='CNN')
    plt.plot(Time, gaussian_filter1d(10 * np.log10(ErroC_CNN**2), sigma=sigma), label = 'FxMCC')
    plt.plot(Time, gaussian_filter1d(10 * np.log10(ErroC_LSTM**2), sigma=sigma), label = 'LSTM')

    plt.title('(c)')
    plt.xlabel('Time (seconds)')
    plt.ylabel('MSE (dB)')

    # =============================================================================================
    # id_vector
    print(f"id_vector:{id_vector}")
    print(f"id_CNN:{id_vector_CNN}")
    print(f"id_LSTM:{id_vector_LSTM}")
    figure(4)
    plt.plot(id_vector_CNN, '+', linewidth=5, label = 'CNN selected index')
    plt.plot( id_vector_LSTM, 'x', linewidth=5, label='LSTM selected index')
    plt.plot(id_vector, linewidth=1, label = 'Actual index')
    # plt.xticks(np.arange(0, T * 2, 1))
    plt.title('(d)')
    plt.xlabel('Time (seconds)')
    plt.ylabel('Index')

    # =============================================================================================
    # id_vector
    figure(5)
    plt.plot(unkonwm_Sz, label ='Unknown secondary path')
    plt.plot(predicted_Sec_path, label = 'Predicted Secondary Path')
    # plt.plot(Sec_path, label = 'guess_Sz')
    plt.grid()
    plt.legend(loc=1)

    # =============================================================================================
    plt.show()


