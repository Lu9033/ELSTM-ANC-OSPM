import math
import os

import numpy as np
import torch
import torchaudio
from scipy import signal

from create_Yn import DatasetSheet

import warnings
warnings.filterwarnings("ignore")

def SimilarityRato(f1_min, f1_max, f2_min, f2_max):
    if (f1_min <= f2_min):
        if (f1_max <= f2_min):
            return 0
        elif (f2_min <= f1_max) & (f1_max <= f2_max):
            return (f1_max - f2_min) / (f2_max - f1_min)
        else:
            return (f2_max - f2_min) / (f1_max - f1_min)
    else:
        if (f2_max <= f1_min):
            return 0
        elif (f1_min <= f2_max) & (f2_max <= f1_max):
            return (f2_max - f1_min) / (f1_max - f2_min)
        else:
            return (f1_max - f1_min) / (f2_max - f2_min)
class ClassID_Calculator:

    def __init__(self, levels):
        self.f_vector = levels
        self.len = len(self.f_vector)

    def _get_ID_(self, f_low, f_high):
        SimlarityRatio = []
        for ii in range(self.len):
            SimlarityRatio.append(SimilarityRato(f_low, f_high, self.f_vector[ii][0], self.f_vector[ii][1]))
        ID = SimlarityRatio.index(max(SimlarityRatio))
        return ID, SimlarityRatio
def additional_noise(signal, snr_db):
    signal_power = signal.norm(p=2)
    length = signal.shape[1]
    additional_noise = np.random.randn(length)
    additional_noise = torch.from_numpy(additional_noise).type(torch.float32).unsqueeze(0)
    noise_power = additional_noise.norm(p=2)
    snr = math.exp(snr_db / 10)
    scale = snr * noise_power / signal_power
    noisy_signal = (scale * signal + additional_noise) / 2
    return noisy_signal
# -----------------------------------------------------------------------------------
# Description : Creat alpha noise
# -----------------------------------------------------------------------------------
def rasd_noise(N, alpha = 1.8, beta = 0, gama = 1, miu = 0):
    # ----- 均匀分布 -----
    nuni = np.random.rand(N)
    U = (nuni * np.pi) - np.pi / 2
    # ----- 指数分布 -----
    zhi = np.random.rand(N)
    W = -np.log(zhi)

    if alpha != 1:
        X1 = S(alpha, beta)
        X2 = np.sin(alpha * (U + B(alpha, beta))) / (np.cos(U) ** (1 / alpha))
        X3 = (np.cos(U - alpha * (U + B(alpha, beta))) / W) ** (1 / alpha - 1)
        X = X1 * X2 * X3
    else:
        X = (2 / np.pi) * ((np.pi / 2 + beta * U) * np.tan(U) - beta * np.log(0.5 * np.pi * W * np.cos(U) / (np.pi / 2 + beta * U)))

    if alpha != 1:
        Y = gama * X + miu
    else:
        Y = gama * X + miu + (2 / np.pi) * beta * gama * np.log(gama)
    return Y

def B(alpha, beta):
    return np.arctan(beta * np.tan(np.pi * alpha / 2)) / alpha

def S(alpha, beta):
    return (1 + beta ** 2 * (np.tan(np.pi * alpha / 2)) ** 2) ** (1 / (2 * alpha))

# -----------------------------------------------------------------------------------
# Description : Creat k noise
# -----------------------------------------------------------------------------------
def k_distribution(len, nu = 4, lambda_param = 1):
    x = np.random.randn(len)
    y = np.random.gamma(nu / 2, scale=2 / lambda_param, size=len)
    k_noise = np.sqrt(2 * y / nu) * x
    return k_noise

# -----------------------------------------------------------------------------------
# Description : Creat mixed-gauss noise
# -----------------------------------------------------------------------------------
def gaussian_mixture_noise(num_samples, num_components = 3, means = [0, 5, -3], variances = [1, 2, 0.5]):
    # num_samples: 要生成的噪声样本数量
    # num_components: 高斯分布的组件数量
    # means: 一个包含每个高斯分布均值的列表或数组
    # variances: 一个包含每个高斯分布方差的列表或数组
    # 检查输入参数的维度是否匹配
    if len(means) != num_components or len(variances) != num_components:
        raise ValueError('Means and variances lists must have the same length as the number of components.')
    # 为每个样本随机选择一个高斯分布组件
    components = np.random.randint(0, num_components, num_samples)
    # 初始化混合噪声数组
    mixed_noise = np.zeros(num_samples)
    # 遍历每个样本，并从对应的高斯分布中抽取值
    for i in range(num_samples):
        component = components[i]
        mixed_noise[i] = np.random.normal(means[component], np.sqrt(variances[component]))
    return mixed_noise

# -----------------------------------------------------------------------------------
# Description : Creat chaos noise
# -----------------------------------------------------------------------------------
def chaotic_noise(num_samples, r = 3.99, x0 = 0.5):
    # num_samples: 要生成的噪声样本数量
    # r: Logistic映射的参数，通常在(3.57, 4]范围内
    # x0: 初始条件，通常在(0, 1)范围内
    # 初始化噪声数组
    chaotic_noise = np.zeros(num_samples)
    # 设置初始值
    x = x0
    # 生成混沌序列
    for i in range(num_samples):
        x = r * x * (1 - x)  # Logistic映射公式
        chaotic_noise[i] = x  # 将混沌值存储在噪声数组中
        # 可选：为了将值限制在特定范围内或进行归一化，可以添加额外的处理步骤
        # 例如，将值缩放到[0, 1]范围（实际上Logistic映射已经在这个范围内）
        # 或者将其转换为其他范围，如[-1, 1]
        chaotic_noise[i] = 2 * x - 1  # 缩放到[-1, 1]
    # 可选：为了模拟噪声的平滑变化，可以对混沌序列进行滤波
    # 例如，使用简单移动平均滤波器
    # window_size = 5  # 需要定义窗口大小
    # chaotic_noise = np.convolve(chaotic_noise, np.ones(window_size)/window_size, mode='valid')
    # 注意：使用卷积进行滤波会减少输出数组的长度，因此可能需要调整num_samples或截断结果
    return chaotic_noise

# -----------------------------------------------------------------------------------
# Description : Creat gauss noise
# -----------------------------------------------------------------------------------
def gauss_noise(N):
    noise =np.random.randn(N)
    return noise

class Noise_type:
    def __init__(self):
        self.len_f = 1024
    def __mixed_gauss_Noise_generation__(self, f_star, Bandwidth, fs, N):
        # f_star indecats the start of frequency band (Hz)
        # Bandwith denots the bandwith of the boradabnd noise
        # fs denots the sample frequecy (Hz)
        # N represents the number of point
        f_end = f_star + Bandwidth
        b2 = signal.firwin(self.len_f, [f_star, f_end], pass_zero='bandpass', window='hamming', fs=fs)
        Re = gaussian_mixture_noise(N)
        Re = signal.lfilter(b2, 1, Re)
        Noise = Re[self.len_f - 1:]
        # ----------------------------------------------------
        return Noise / np.sqrt(np.var(Noise))
    def __alpha_Noise_generation__(self, f_star, Bandwidth, fs, N):
        # f_star indecats the start of frequency band (Hz)
        # Bandwith denots the bandwith of the boradabnd noise
        # fs denots the sample frequecy (Hz)
        # N represents the number of point
        f_end = f_star + Bandwidth
        b2 = signal.firwin(self.len_f, [f_star, f_end], pass_zero='bandpass', window='hamming', fs=fs)
        Re = rasd_noise(N)
        Re = signal.lfilter(b2, 1, Re)
        Noise = Re[self.len_f - 1:]
        # ----------------------------------------------------
        return Noise / np.sqrt(np.var(Noise))
    def __k_distribution_Noise_generation__(self, f_star, Bandwidth, fs, N):
        # f_star indecats the start of frequency band (Hz)
        # Bandwith denots the bandwith of the boradabnd noise
        # fs denots the sample frequecy (Hz)
        # N represents the number of point
        f_end = f_star + Bandwidth
        b2 = signal.firwin(self.len_f, [f_star, f_end], pass_zero='bandpass', window='hamming', fs=fs)
        Re = k_distribution(N)
        Re = signal.lfilter(b2, 1, Re)
        Noise = Re[self.len_f - 1:]
        # ----------------------------------------------------
        return Noise / np.sqrt(np.var(Noise))
    def __chaos_Noise_generation__(self, f_star, Bandwidth, fs, N):
        # f_star indecats the start of frequency band (Hz)
        # Bandwith denots the bandwith of the boradabnd noise
        # fs denots the sample frequecy (Hz)
        # N represents the number of point
        f_end = f_star + Bandwidth
        b2 = signal.firwin(self.len_f, [f_star, f_end], pass_zero='bandpass', window='hamming', fs=fs)
        Re = chaotic_noise(N)
        Re = signal.lfilter(b2, 1, Re)
        Noise = Re[self.len_f - 1:]
        # ----------------------------------------------------
        return Noise / np.sqrt(np.var(Noise))
    def __gauss_Noise_generation__(self, f_star, Bandwidth, fs, N):
        # f_star indecats the start of frequency band (Hz)
        # Bandwith denots the bandwith of the boradabnd noise
        # fs denots the sample frequecy (Hz)
        # N represents the number of point
        f_end = f_star + Bandwidth
        b2 = signal.firwin(self.len_f, [f_star, f_end], pass_zero='bandpass', window='hamming', fs=fs)
        Re = gauss_noise(N)
        Re = signal.lfilter(b2, 1, Re)
        Noise = Re[self.len_f - 1:]
        # ----------------------------------------------------
        return Noise / np.sqrt(np.var(Noise))

def noise_generator_select(flag, generation,f_star, Bandwidth, fs, N):
    noise = []
    if flag == 0:
        noise = generation.__mixed_gauss_Noise_generation__(f_star, Bandwidth, fs, N)
    if flag == 1:
        noise = generation.__alpha_Noise_generation__(f_star, Bandwidth, fs, N)
    if flag == 2:
        noise = generation.__k_distribution_Noise_generation__(f_star, Bandwidth, fs, N)
    if flag == 3:
        noise = generation.__chaos_Noise_generation__(f_star, Bandwidth, fs, N)
    if flag == 4:
        noise = generation.__gauss_Noise_generation__(f_star, Bandwidth, fs, N)
    return noise


class noise_generator:
    def __init__(self, type, fs, folder):
        self.noise_type = ['mixed_gauss_Noise', 'alpha_Noise', 'k_distribution_Noise', 'chaos_Noise', 'gauss_Noise']
        self.type = type
        self.fs = fs
        self.len = fs + 1023
        self.folder = folder
        self.Num = 0
        try:
            os.mkdir(folder)
        except:
            print("folder exists")

        self.generation = Noise_type()

    def __construct__(self):
        self.Num = self.Num + 1
        f_star = np.random.uniform(1, 1000, 1)
        bandWidth = np.random.uniform(1, 1000 - f_star, 1)
        f_end = f_star + bandWidth
        filename = f'{self.noise_type[self.type]}_' + f'{self.Num}_Frequency_from_' + f'{f_star[0]:.0f}_to_{f_end[0]:.0f}_Hz.wav'
        filePath = os.path.join(self.folder, filename)
        noise = noise_generator_select(self.type, self.generation, f_star[0], bandWidth[0], self.fs, self.len)
        noise = torch.from_numpy(noise).type(torch.float32).unsqueeze(0)
        torchaudio.save(filePath, noise, self.fs)
        return f_star[0], f_end[0], filename

    def __construct_A__(self):
        self.Num = self.Num + 1
        f_star = np.random.uniform(1, 1000, 1)
        bandWidth = np.random.uniform(1, 1000 - f_star, 1)
        f_end = f_star + bandWidth
        filename = f'{self.noise_type[self.type]}_' + f'{self.Num}_Frequency_from_' + f'{f_star[0]:.0f}_to_{f_end[0]:.0f}_Hz_A.wav'
        filePath = os.path.join(self.folder, filename)
        noise = noise_generator_select(self.type, self.generation, f_star[0], bandWidth[0], self.fs, self.len)
        noise = torch.from_numpy(noise).type(torch.float32).unsqueeze(0)
        snr_db = np.random.uniform(3, 60, 1)
        noise = additional_noise(noise, snr_db)
        torchaudio.save(filePath, noise, self.fs)
        return f_star[0], f_end[0], filename

    def __balance_construct__(self, Fre_noise_vector):
        self.Num = self.Num + 1
        filename = f'{self.noise_type[self.type]}_' + f'{self.Num}_Frequency_from_' + f'{Fre_noise_vector[0]:.0f}_to_{Fre_noise_vector[1]:.0f}_Hz.wav'
        filePath = os.path.join(self.folder, filename)
        noise = noise_generator_select(self.type, self.generation, Fre_noise_vector[0], Fre_noise_vector[1] - Fre_noise_vector[0], self.fs,self.len)
        noise = torch.from_numpy(noise).type(torch.float32).unsqueeze(0)
        torchaudio.save(filePath, noise, self.fs)
        return filename

    def __balance_construct_A__(self, Fre_noise_vector):
        self.Num = self.Num + 1
        filename = f'{self.noise_type[self.type]}_' + f'{self.Num}_Frequency_from_' + f'{Fre_noise_vector[0]:.0f}_to_{Fre_noise_vector[1]:.0f}_Hz.wav'
        filePath = os.path.join(self.folder, filename)
        noise = noise_generator_select(self.type, self.generation, Fre_noise_vector[0], Fre_noise_vector[1] - Fre_noise_vector[0], self.fs,self.len)
        noise = torch.from_numpy(noise).type(torch.float32).unsqueeze(0)
        snr_db = np.random.uniform(3, 60, 1)
        noise = additional_noise(noise, snr_db)
        torchaudio.save(filePath, noise, self.fs)
        return filename
def Generating_balance_sampleset_frequency_band_vector(Frequecy_band, Sample_set_number):
    Max_number = Sample_set_number
    ID_calculator = ClassID_Calculator(Frequecy_band)
    Class_count = np.zeros(len(Frequecy_band))
    Class_num = len(Frequecy_band)
    Fre_noise_band = []
    Fre_target = []
    # -------------------------------------------------------------------------------------
    Continue_flag = True
    while Continue_flag:
        F_band = np.sort(np.random.uniform(1, 1000, 2))
        if F_band[0] == F_band[1]:
            continue
        ID, _ = ID_calculator._get_ID_(f_low=F_band[0], f_high=F_band[1])
        if Class_count[ID] < Max_number:
            Fre_noise_band.append(F_band)
            Fre_target.append(ID)
            Class_count[ID] += 1

        if np.sum(Class_count == Max_number) == Class_num:
            Continue_flag = False
        else:
            Continue_flag = True
    return Fre_noise_band, Fre_target

if __name__ == "__main__":
    file_name = "Index.csv"
    Folder_name = 'X_n_test_40Sz'
    N_sample_each_class = 1
    datasheet = DatasetSheet(Folder_name, file_name)
    F_bands = [[1, 230], [200, 420], [400, 630], [600, 820], [800, 1000]]
    for ii in range(0,5):
        Generator = noise_generator(type=ii,fs=16000, folder=Folder_name)
        Fre_noise_band, Fre_target = Generating_balance_sampleset_frequency_band_vector(Frequecy_band=F_bands,
                                                                                        Sample_set_number=N_sample_each_class)
        Fre_noise_band_A, Fre_target_A = Generating_balance_sampleset_frequency_band_vector(Frequecy_band=F_bands,
                                                                                            Sample_set_number=N_sample_each_class)

        for Fre_noise_vector, Fre_target_element, Fre_noise_vector_A, Fre_target_element_A in zip(Fre_noise_band,
                                                                                                  Fre_target,
                                                                                                  Fre_noise_band_A,
                                                                                                  Fre_target_A):
            filePath = Generator.__balance_construct__(Fre_noise_vector=Fre_noise_vector)
            datasheet.add_data_to_file(filePath, Fre_target_element)

            filePath = Generator.__balance_construct_A__(Fre_noise_vector=Fre_noise_vector_A)
            datasheet.add_data_to_file(filePath, Fre_target_element_A)
        datasheet.flush()