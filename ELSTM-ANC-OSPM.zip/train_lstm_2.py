import torch
from scipy.io import savemat
from torch import nn
import tqdm
from Bcolors import bcolors
from LSTM import LSTM, LSTM_CNN
from Loss import calculate_loss
from Mydataloader import MyDataset, create_data_loader

import warnings
warnings.filterwarnings("ignore")

import numpy as np
import torch
import random
import os

LOSS = []
# seed_value = 42   # 设定随机数种子
# np.random.seed(seed_value)
# random.seed(seed_value)
# os.environ['PYTHONHASHSEED'] = str(seed_value)  # 为了禁止hash随机化，使得实验可复现。
#
# torch.manual_seed(seed_value)     # 为CPU设置随机种子
# torch.cuda.manual_seed(seed_value)      # 为当前GPU设置随机种子（只用一块GPU）
# # torch.cuda.manual_seed_all(seed_value)   # 为所有GPU设置随机种子（多块GPU）
#
# torch.backends.cudnn.deterministic = True


def train(model, data_loader, eva_data_loader, loss_fn, optimiser, device, epochs, MODEL_PTH=None):
    acc_max = 0
    acc_train_max = 0
    for i in range(epochs):
        print(f"Epoch {i+1}")
        acc_train    = train_single_epoch(model, data_loader, loss_fn, optimiser, device)
        acc_validate = validate_single_epoch(model, eva_data_loader, loss_fn, device)
        if acc_validate > acc_max:
            acc_train_max, acc_max = acc_train, acc_validate
            torch.save(model.state_dict(), MODEL_PTH)
            print(bcolors.OKCYAN + "MODEL SAVED!!!" + bcolors.ENDC)
        print("--------------------------------------------------------------------------------")
    print("Training progress complete!")
    return acc_train_max, acc_max

def train_single_epoch(model, data_loader, loss_fn, optimiser, device):
    train_loss = 0
    train_acc = 0
    model.train()

    progress_bar = tqdm.tqdm(total=len(data_loader), desc="Training Progress")
    for input, target in data_loader:
        input, target = input.to(device), target.to(device)
        b, s, h = target.shape
        # calculate loss
        prediction = model(input)
        loss = loss_fn(prediction.reshape(b,s,h), target)
        LOSS.append(loss.item())
        # back propagate error and update weights
        optimiser.zero_grad()
        loss.backward()
        optimiser.step()
        train_loss += loss.item()
        # Recording the loss and accuracy
        cos = nn.CosineSimilarity(dim=1).to(device)
        similarity = cos(target.reshape(b,-1).to(device), prediction.reshape(b,-1).to(device))
        similarity = torch.mean(similarity, dim=0)
        train_acc += similarity.cpu().item()
        # progress_bar.set_postfix({'Acc': similarity.item()})
        progress_bar.update(1)

    progress_bar.close()
    savemat('Sz_LSTM_LOSS.mat', {'Loss': LOSS})
    print(f"loss: {train_loss / len(data_loader)}")
    print(f"train acc : {train_acc / (len(data_loader))}")
    return train_acc / (len(data_loader))

def validate_single_epoch(model, eva_data_loader, loss_fn, device):
    eval_loss = 0
    eval_acc = 0
    i = 0
    model.eval()
    progress_bar = tqdm.tqdm(total = 40,desc = "Validate Progress")
    for input, target in eva_data_loader:
        i += 1
        input, target = input.to(device), target.to(device)
        b, s, h = target.shape
        # Calculating the loss value
        prediction = model(input)
        loss = loss_fn(prediction, target)
    # recording the validating loss and accuratcy
        eval_loss += loss.item()
        cos = nn.CosineSimilarity(dim=1).to(device)
        similarity = cos(target.reshape(b, -1).to(device), prediction.reshape(b, -1).to(device))
        similarity = torch.mean(similarity, dim=0)
        eval_acc += similarity
        progress_bar.update(1)

        if i == 40 : break
    progress_bar.close()
    print(f"Validat loss : {eval_loss / len(eva_data_loader)}" + f" Validate acc : {eval_acc / 40}")
    return eval_acc / 40

if __name__ == "__main__":
    BATCH_SIZE = 50
    EPOCHS = 40
    LEARNING_RATE = 0.001
    File_sheet = 'Index.csv'
    ANNOTATIONS_FILE = 'Train_data_40Sz'
    VALIDATION_FILE = "Validate_data_40Sz"
    MODEL_PTH = 'Sz_predict_40Sz_forloss_1.pth'
    Sz_file = "Sz_40.mat"
    train_data = MyDataset(ANNOTATIONS_FILE, File_sheet, Sz_file)
    valid_data = MyDataset(VALIDATION_FILE,File_sheet, Sz_file)

    train_dataloader = create_data_loader(train_data, BATCH_SIZE)
    valid_dataloader = create_data_loader(valid_data,int(BATCH_SIZE/10))

    # construct model and assign it to device
    if torch.cuda.is_available():
        device = "cuda"
    else:
        device = "cpu"
    print(f"Using {device}")

    feed_forward_net  = LSTM().to(device)
    print(feed_forward_net)

     # initialise loss funtion + optimiser
    loss_fn = calculate_loss
    optimiser = torch.optim.Adam(feed_forward_net.parameters(),lr=LEARNING_RATE)

    # train model
    train(feed_forward_net, train_dataloader, valid_dataloader, loss_fn, optimiser, device, EPOCHS, MODEL_PTH=MODEL_PTH)

    print("Training progress complete!")

