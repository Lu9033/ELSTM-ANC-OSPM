import numpy as np
from lstm_pre import LSTM_Predictor


class Control_filter_Index_predictor_LSTM(LSTM_Predictor):

    def __init__(self, MODEL_PATH, device, filter_training_noise, fs):

        LSTM_Predictor.__init__(self, MODEL_PATH, device)
        # Checking the length of the training noise
        assert filter_training_noise.dim() == 3, 'The dimension of the training noise should be 3 !!!'
        assert filter_training_noise.shape[2] % fs == 0, 'The length of the training noise sample should be 1 second!'
        # Detach the information of the training noise
        self.frequency_charactors_tensor = filter_training_noise
        self.len_of_class = filter_training_noise.shape[0]
        self.fs = fs

    def predic_ID(self, noise):
        similarity_rato = []
        for ii in range(self.len_of_class):
            similarity_rato.append(self.cosSimilarity_minmax(noise, self.frequency_charactors_tensor[ii][:, :self.fs]))
        index = np.argmax(similarity_rato)
        return index

    def predic_ID_vector(self, primary_noise):
        # Checking the length of the primary noise.
        assert primary_noise.shape[0] == 1, 'The dimension of the primary noise should be [1 x samples] !!!'
        assert primary_noise.shape[
                   1] % self.fs == 0, 'The length of the primary noise is not an integral multiple of fs.'
        # Computing how many seconds the primary noise containt.
        Time_len = int(primary_noise.shape[1] / self.fs)
        # print(Time_len)
        # print(f'The primary nosie has {Time_len} seconds !!!')
        # Bulding the matric of the primary noise [times x 1 x fs ]
        primary_noise_vectors = primary_noise.reshape(Time_len, self.fs).unsqueeze(1)

        # Implementing the noise classification for each frame whose length is 1 second.
        ID_vector = []
        for ii in range(Time_len):
            ID_vector.append(self.predic_ID(primary_noise_vectors[ii]))

        return ID_vector
